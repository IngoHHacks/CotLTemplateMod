## TemplateMod

This is a template mod for Cult of the Lamb